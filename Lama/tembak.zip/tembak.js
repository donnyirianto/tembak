const { Console } = require('console');
const fs = require('fs');
const venvLocal = require('./Models/venvLocal');
const vquery = require('./Models/vquery');
const connection = require('./Models/zconn');
const Models = require('./modelsnew/model')


process.setMaxListeners(0);

const sleep = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds))
} 

const deleteFile = (filePath) => {
  // Unlink the file.
  fs.unlink(filePath, (error) => {
    if (!error) {
       return "Sukses Hapus"
    } else {
      return "Gagal Hapus"
    }
  })
};

const doitBro = async () => {
    try {    
      const start = new Date();
      console.log("Running At : " + start)   
      while(true){         
          (async ()=>{
              try{  
                deleteFile('./data.txt');    
                const fileReport = fs.createWriteStream("data.txt");   
                fileReport.once('open', async function(fd) { 
                  fs.appendFile('data.txt',"let Donny = [", errx => {
                    if (errx) {
                      console.log("error Tulis File")
                      return true
                    } 
                  })     
                  const results = await Models.getListIp();

                  results.forEach( async (r) => { 
                    // ANCHOR ===============Query Ambil Data ========================= 
                   //const queryTembak = "SET GLOBAL slow_query_log = 1; SET GLOBAL long_query_time=30; SET GLOBAL log_output='table'; FLUSH LOGS;"
                 /*  const queryTembak = `
                  SET GLOBAL slow_query_log = 1; SET GLOBAL long_query_time=30; SET GLOBAL log_output='table'; FLUSH LOGS;
                  `; 
                  
                  delete from fixed_tb where plu = ${r.prdcd} and qty = 20;

delete from fixed_tb_new where plu = ${r.prdcd};

insert into fixed_tb (RECID, GUDANG, PLU, QTY, UPDATED, TGL_AWAL, TGL_AKH, HARI_MAIN, STS, CSV, JENIS_FT)
select RECID, GUDANG, PLU, QTY, UPDATED, TGL_AWAL, TGL_AKH, HARI_MAIN, STS, CSV, JENIS_FT
from (select * from fixed_tb_new where plu = ${r.prdcd} order by qty desc limit 1) a;

                  */

                  const queryTembak = `
                  UPDATE PROGRAM_SETTING SET NILAI = '5' WHERE program like '%realt%' and jenis = 'INTERVALGETTASK';
                  `
                   const rv = await Models.vqueryTembak(r.ip1, queryTembak)
                    //const rv= await Models.vqueryTembak(r.ip1, `SET GLOBAL max_allowed_packet=1073741824;`)
                   if(rv === "Gagal"){
                      console.log(r.kdtk +'|'+ r.kdcab +'|Gagal') 
                    }else{                       
                        console.log(r.kdtk +'|'+ r.kdcab +'|Sukses')
                    }
                    
                  })
                })
              }catch(err){
                console.log("Sini Ketnya : " + err) 
                return true
              }

          })(); 
        await sleep(3600000)            
      }
    } catch (e) {
      console.log("Sini 2" + e);
      //doitBro()
    } 
}
 
doitBro()