const conn_local = require('../services/db');
const conn_iris = require('../services/db2');
//const conn_ho = require('../services/dbho');
const zconn = require('../services/anydb'); 
const ftp = require('../services/ftp'); 
var dateFormat = require("dateformat");

const getListIpInitial = async (kdcab) => {
    try{
        //'G004','G025','G030','G034','G097','G146','G148','G149','G158','G174','G177','G301','G305') 
        const [rows] = await conn_local.query(`
            SELECT * FROM ip 
            WHERE kdcab in (${kdcab})
            AND KDTK NOT IN(SELECT KDTK FROM INITIAL WHERE KDCAB IN(${kdcab}) )
            
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}
const getListIpBap= async (kdcab) => {
    try{
        //'G004','G025','G030','G034','G097','G146','G148','G149','G158','G174','G177','G301','G305') 
        const [rows] = await conn_local.query(`
            SELECT a.*,b.ip1 FROM bap2 a
            left join ip b on a.kdtk = b.kdtk           
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}
const getListIp = async () => {
    try{
       //where kdcab in('G097','G174','G030','G177','G158')
        const [rows] = await conn_local.query(`
        select * from ip where kdtk in('FPPI','FYS1','T7K3','T5LP','TQ40','TRRN','TB0S','T39Q','FSRY','TYAW','TQWV','TMTF','TRB2','TZZW','FZPP','TTGB','T2DS','TYGI','FGHU','TO6C','FFG7','TP6O','TM4X','TYW5')
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}  


const getListIpHijau = async () => {
    try{
       //where kdcab in('G097','G174','G030','G177','G158')
        const [rows] = await conn_local.query(`
        select * from ip where kdcab in('G305','G004','G148','G146','G025','G301','G034')
        and kdtk in ('F1U4','FC1X','FEEO','T19T','T8T0','TATO','TCJ3','TDEF','TEAH','TGYY','TIRI','TK9V','TKZN','TMLG','TR7B','TSGK','TY5X')
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}

const getListIpKuning = async () => {
    try{
       //where kdcab in('G097','G174','G030','G177','G158')
        const [rows] = await conn_local.query(`
        select * from ip where kdcab in('G030','G174','G177')
        and kdtk in ('FPME','TBMG','TCOD','TDKP','THTK','TIAS','TRFI','TWRR')
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}

const getListIpOrange = async () => {
    try{
       //where kdcab in('G097','G174','G030','G177','G158')
        const [rows] = await conn_local.query(`
        select * from ip where kdcab in('G158','G149','G097')
        and kdtk in('TDUO','TMM8','TRLG')
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}


const getListHampers = async () => {
    try{
       //where kdcab in('G097','G174','G030','G177','G158')
        const [rows] = await conn_local.query(`
        select * from ip where kdcab in('G301','G305','G025','G004','G148')
        and kdtk in('TMLG','F1L3','FW6C','T8T0','TR7B','FGJJ','F2S7','FDYI','FAEM','FE76','FDOJ','FSEF','FXV7','F0EP','FWRE','FWUD','FXX1','FTMV','FT62','T1BK','T41G','T4U4','FXNS','T6HF','T4UJ','T5F2','T8C0','T3MT','TA09','TAXM','TCIH','T60T','TCAM','T639','TAJY','TEBL','TEAL','T33P','TF72','TF08','TGTO','TH7H','TDA0','TA56','TC4N','TCUS','T9NN','TF33','TGWO','TCL0','TEH9','TJAG','TH3A','T8JW','TDQQ','TGQT','TF02','TEOT','TRMT','TC9R','TGOG','TROG','TBMR','T6FH','TESQ','TTRN','TR5Y','TEO5','TP4O','TTBH','TKLJ','THPM','T6AR','TVQE','TF04','T8OT','FX02','TFFF','TAH6','TBGE','FVNA','TSGK','TSKZ','TZMT','TGDC','TX9S','TY5X','F41F','T0YQ','F11F','TEWJ','TV5G','FP1E','TMAU','T3E6','TVZF','FQMD','T02P','TGY1','T2GG','F0ZX','F1U4','F46N','FC1X','FE7Y','FIVI','FJ3O','FJJK','FQYG','FU7Y','FX9X','T0R5','T609','T628','T676','T8TX','TA17','TCJ3','TCO0','TDD7','TEAH','TFAD','TFGJ','TFPV','TFTA','TGYY','TGZT','TH5A','TJ1U','TJDR','TK9V','TKWU','TR71','TRSA','TSLM','TV76','TVRY','TVXL','TY45','TYZU','TXCA','TICD','TPOU','TF7J')
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}


const getListIpFt = async () => {
    try{
        const [rows] = await conn_local.query(`
            select * from zarvi.tembak_ft a 
            left join zarvi.ip b on a.kdtk = b.kdtk 
            limit 1
        `)
        return rows
    }catch(e){
        return "Error"
    }
}  

const ftpdel = async (ip, namafile) => {
    try{
        //'G025','G030','G034','G097','G146','G148','G149','G158','G174','G301','G305') 
        const rows = await ftp.ceckfile(ip,namafile);
        return rows
    }catch(e){
        return "Gagal"
    }
} 

const ftpcek = async (ip, namafile) => {
    try{
        //'G025','G030','G034','G097','G146','G148','G149','G158','G174','G301','G305') 
        const rows = await ftp.ceckfile(ip,namafile);
        return rows
    }catch(e){
        return "Gagal"
    }
} 
const getListIpPco = async () => {
    try{
        //'G025','G030','G034','G097','G146','G148','G149','G158','G174','G301','G305') 
        const [rows] = await conn_local.query(`
            select * from ip where kdtk in('F38Y','F69C','FAIJ','FGC6','FKHP','FLLB','FMI9','FN8D','FWBG','T11F','T1LU','T23F','T3KH','T3WJ','T56Q','T5CR','T61Q','T7MH','T84F','T9FS','T9HH','TAUJ','TAUN','TBAT','TBJI','TCFR','TDYI','TEKK','TF58','TF62','TF75','TGPX','TGY1','THGO','THH5','TJAG','TKLK','TLES','TN6W','TO08','TOFL','TP4P','TPMX','TQ16','TR7G','TRDE','TREM','TRPH','TT43','TT66','TUHT','TV5G','TVS9','TVZQ','TXIE','TY80','TY95','TYWE','TZMY','TZZW','T0NA','TCV6','TEAL','THHD','TUCX','TYFR','TERI','TART','TDXW','TNJP','T42R','TDME','FNHD','FOSL','TTSD','TQLZ','FGMN','FA5A','TMGG','FSUE','FSUF','TTXS','FD44','TQQQ','TF66','TSEV','T020','TLKS','T60T')
        `)
        return rows
    }catch(e){
        return "Error"
    }
} 

const getListIpRekon = async () => {
    try{
        //'G004','G025','G030','G034','G097','G146','G148','G149','G158','G174','G177','G301','G305') 
        const [rows] = await conn_local.query(`
            select * from ip where kdcab in ('G004','G025','G030','G034','G097','G146','G148','G149','G158','G174','G177','G301','G305')
            and kdtk not in
            (select kdtk from m_rekonsales where wdate=curdate()-1)
            
        `)
        return rows
    }catch(e){
        console.log(e)
        return "Error"
    }
}

const getListIpIntransit = async () => {
    try{
        //'G025','G030','G034','G097','G146','G148','G149','G158','G174','G301','G305') 
        const [rows] = await conn_local.query(`
        select b.kdtk,b.nama,b.kdcab,b.ip1,a.docnonpb from intransit a left join ip b on a.kdtk=b.kdtk
        `)
        return rows
    }catch(e){
        return "Error"
    }
} 


const vquery = async (iptoko, param) => {
    try{
        
        const rows = await zconn.zconn(iptoko,"kasir","D5SgTTMDME9E4yLxI4CRw/+suEYGcL0YE=NmOUnkyrZZ","pos", 3306, param)
        if(rows === "Gagal"){
            const rows2 = await zconn.zconn(iptoko,"kasir","iUL+J2zDwNbP1FEWjqpa4jZhPPB4yyDYE=MORFTmyGZn","pos", 3306, param)
            if(rows2 === "Gagal"){
                return "Gagal"
            }else{
                return rows2
            }
        }else{
            return rows
        }
        
    }catch(e){ 
        
        return "Gagal"
    }
} 

const vqueryTembak = async (iptoko, param) => {
    try{
        /*
         const rows = await zconn.zconnTembak(iptoko,"root","5CCNQV3rio/dI/iboPPnww9nzUHh8bpac=fU59bpWfE4","pos", 3306, param)
        if(rows === "Gagal"){
            const rows2 = await zconn.zconnTembak(iptoko,"kasir","N8rM5RmJYbKGbEFWuvuSb6bauDFB3BPTc=zOMd2onoNJ","pos", 3306, param)
        
        kasir baru 
        D5SgTTMDME9E4yLxI4CRw/+suEYGcL0YE=NmOUnkyrZZ
        kasir lama 
        iUL+J2zDwNbP1FEWjqpa4jZhPPB4yyDYE=MORFTmyGZn
        root1 
        5CCNQV3rio/dI/iboPPnww9nzUHh8bpac=fU59bpWfE4
        root2
        N8rM5RmJYbKGbEFWuvuSb6bauDFB3BPTc=zOMd2onoNJ
        */
        const rows = await zconn.zconnTembak(iptoko,"kasir","D5SgTTMDME9E4yLxI4CRw/+suEYGcL0YE=NmOUnkyrZZ","pos", 3306, param)
        if(rows === "Gagal"){
            const rows2 = await zconn.zconnTembak(iptoko,"root","5CCNQV3rio/dI/iboPPnww9nzUHh8bpac=fU59bpWfE4","pos", 3306, param)
            if(rows2 === "Gagal"){
                return "Gagal"
            }else{
                return rows2
            }
        }else{
            return rows
        }
        
    }catch(e){ 
        //console.log(e)
        return "Gagal"
    }
} 


const vqueryTembakMany = async (iptoko, query1,query2,query3,query4,query5,query6,query7) => {
    try{
        const rows = await zconn.zconnTembakMany(iptoko,"kasir","D5SgTTMDME9E4yLxI4CRw/+suEYGcL0YE=NmOUnkyrZZ","pos", 3306, query1,query2,query3,query4,query5,query6,query7)
        if(rows === "Gagal"){
            const rows2 = await zconn.zconnTembakMany(iptoko,"kasir","5CCNQV3rio/dI/iboPPnww9nzUHh8bpac=fU59bpWfE4","pos", 3306, query1,query2,query3,query4,query5,query6,query7)
            if(rows2 === "Gagal"){
                return "Gagal"
            }else{
                return rows2
            }
        }else{
            return rows
        }
        
    }catch(e){ 
        //console.log(e)
        return "Gagal"
    }
} 
 
const insertData = async (kdcab, kdtk, namatoko, data) => {
    try{
        //'G025','G030','G034','G097','G146','G148','G149','G158','G174','G301','G305') 
        //console.log(data)
        var dd = []
        for(const i of data) {     
            
            dd.push(`('${kdcab}' ,'${kdtk}', '${namatoko.toString()}', '${i.SHOP}',
              '${dateFormat(i.WDATE,"yyyy-mm-dd")}','${i.TJUALN}',
              '${i.TRETN}','${i.TPPN}','${i.THPP}','${i.TJUAL}','${i.TRET}',
              '${i.JQTY}','${i.DQTY}','${i.BBS_PPN}')`)
        }
        
        const queryx = `REPLACE INTO m_rekonsales() VALUES ${dd.toString()}`
        await zconn.zconnTembak("localhost","root","n3wbi323m3d","zarvi", 3306, queryx)
      
        return "Sukses Insert"
    }catch(e){
        console.log(e)
        return "Error insert"
    }
} 

const insertDataInitial = async (kdcab, kdtk, namatoko, data) => {
    try{
        //'G025','G030','G034','G097','G146','G148','G149','G158','G174','G301','G305') 
        
        var dd = []
        for(const i of data) {     
            
            dd.push(`('${kdcab}' ,'${kdtk}', '${namatoko.toString()}',
              '${dateFormat(i.TANGGAL,"yyyy-mm-dd")}','${i.STATION}',
              '${i.SHIFT}','${i.NIK}','${i.KASIR_NAME}','${i.TRN_START}','${i.STRUK_AWAL}',
              '${i.TOTAL}')`)
        }
        
        const queryx = `REPLACE INTO initial() VALUES ${dd.toString()}`
        await zconn.zconnTembak("localhost","root","n3wbi323m3d","zarvi", 3306, queryx)
        
        return "Sukses Insert"
    }catch(e){
        console.log(e)
        return "Error insert"
    }
} 
module.exports = {
    vquery, getListIp, vqueryTembak, getListIpPco, getListIpIntransit,ftpdel,ftpcek,vqueryTembakMany, getListIpRekon,
    getListIpFt,insertData,getListIpHijau,getListIpOrange,getListIpKuning,getListHampers,
    getListIpInitial,insertDataInitial,getListIpBap
}
