module.exports = {
    port: 3306,
    host: ip,
    user: "root",
    password: "N8rM5RmJYbKGbEFWuvuSb6bauDFB3BPTc=zOMd2onoNJ",
    database: "pos"
}