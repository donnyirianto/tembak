module.exports = {
    port: 3306,
    host: "192.168.131.71",
    user: "root",
    password: "n3wbi323m3d",
    database: "zarvi" 
}