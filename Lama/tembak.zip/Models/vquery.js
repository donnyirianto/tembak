
module.exports = async (conn, q, params) => new Promise(
    (resolve, reject) => {
      const handler = (error, result) => {
        if (error) {
          reject("Gagal");
        }
        resolve(result);
      }
      conn.query(q, params, handler);
    });